import { Component, OnInit } from '@angular/core';
import { Form, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LoginServService } from '../login-serv.service';
import { MessageDialogComponent, MessageDialogModel } from '../message-dialog/message-dialog.component';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  addEmpForm: FormGroup;
  editEmpForm: FormGroup;
  userData;
  isAddFormHide = true;
  isEditHide = true;
  selId;
  jobValues = ['Admin', 'Associate', 'Project Manager', 'Delivery Manager'];

  constructor(private fb: FormBuilder, private loginService: LoginServService, private _snackBar: MatSnackBar, private router: Router, private dialog: MatDialog) {

  }

  public tableData: any[] = [];
  public displayedColumns: any[] = [];
  tableColumns = [

    { label: "Employee ID", key: "emp_id" },
    { label: "Employee Email", key: "email" },
    { label: 'Job Role', key: 'job_role' },
    { label: "Reporting Manager", key: "rep_man_id" },
    { label: "Actions", key: "actions" }
  ];

  ngOnInit() {

    this.tableColumns.forEach(col => {
      this.displayedColumns.push(col.key);
    });


    this.addEmpForm = this.fb.group({
      emp_id: ['', Validators.compose([Validators.pattern('^[0-9]{6}$'), Validators.required])],
      email: ['', Validators.compose([Validators.email, Validators.required])],
      job_role: ['', Validators.required],
      rep_man_id: ['',  Validators.compose([Validators.pattern('^[0-9]{6}$'), Validators.required])]
    });

    this.editEmpForm = this.fb.group({
      job_role: ['', Validators.required],
      rep_man_id: ['',  Validators.compose([Validators.pattern('^[0-9]{6}$'), Validators.required])]
    });

    this.displayEmployeeList()

  }

  displayEmployeeList() {

    let userReq = {
      emp_id: localStorage.getItem('user_id')
    }

    this.loginService.dispEmployee(userReq).subscribe((res) => {
      console.log('res' + JSON.stringify(res));
      this.userData = res;
      this.tableData = this.userData;
    },
      (err) => {
        console.log("ERROR" + JSON.stringify(err));
      })

  }

  edit(row: any) {
    this.isEditHide = false;
    this.isAddFormHide = true;
    console.log("row :: " + JSON.stringify(row));
    console.log(row.emp_id);
    this.selId = row.emp_id;
  }

  delete(row: any) {


    const message = `Are you sure you want to delete the employee?`;

    const dialogData = new MessageDialogModel("Confirm Action", message);

    const dialogRef = this.dialog.open(MessageDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if(dialogResult)
      {
        this.deleteUser(row);
      }
    });    
  }

  private deleteUser(row: any) {
    console.log("row :: " + JSON.stringify(row));
    let userReq = {
      emp_id: row.emp_id
    };

    this.loginService.delEmployee(userReq).subscribe((res) => {
      console.log('res' + JSON.stringify(res));
      if (res && res.message && res.message.msg_code == 'Delete_Success') {
        this._snackBar.open("Employee Deleted Successfully", "Success", {
          duration: 2000,
        });
        window.location.reload();
      }

      else {
        this._snackBar.open(res.message.desc, "!!", {
          duration: 2000,
        });
      }
    },
      (err) => {
        console.log("ERROR" + JSON.stringify(err));
      });
  }

  onEditSubmit() {

    if (this.editEmpForm.valid) {

      const rep_man_id = this.editEmpForm.get('rep_man_id').value;
      const job_role = this.editEmpForm.get('job_role').value;

      console.log(rep_man_id);
      //send Details to Back-end
      let userReq = {
        emp_id: this.selId,
        job_role: job_role,
        rep_man_id: rep_man_id
      }

      this.loginService.updEmployee(userReq).subscribe((res) => {
        console.log('res' + JSON.stringify(res));
        if (res && res.message && res.message.msg_code == 'Modify_Success') {
          this._snackBar.open("Employee Data Modified Successfully", "Success", {
            duration: 2000,
          });
          window.location.reload();
        }
        else {
          this._snackBar.open(res.message.msg_desc, "!!", {
            duration: 2000,
          });
        }
      },
        (err) => {
          console.log("ERROR" + JSON.stringify(err));
        })
    }
  }

  onAddEmp() {
    this.isAddFormHide = false;
    this.isEditHide = true;
  }

  onAddSubmit() {

    if (this.addEmpForm.valid) {

      const emp_id = this.addEmpForm.get('emp_id').value;
      const email = this.addEmpForm.get('email').value;
      const job_role = this.addEmpForm.get('job_role').value;
      const rep_man_id = this.addEmpForm.get('rep_man_id').value;

      //send Details to Back-end
      let userReq = {
        emp_id: emp_id,
        email: email,
        job_role: job_role,
        rep_man_id: rep_man_id
      }

      this.loginService.addEmployee(userReq).subscribe((res) => {
        console.log('res' + JSON.stringify(res));
        if (res && res.message && res.message.msg_desc == 'Add_Success') {

          this._snackBar.open("Employee Added Successfully", "!!", {
            duration: 2000,
          });
        }
        else {
          this._snackBar.open(res.message.msg_desc, "!!", {
            duration: 2000,
          });
        }
        window.location.reload();
      },
        (err) => {
          console.log("ERROR" + JSON.stringify(err));
        })
    }
  }
}
