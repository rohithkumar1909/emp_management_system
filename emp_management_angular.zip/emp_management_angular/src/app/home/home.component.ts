import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  emp_name;
  emp_role;
  constructor() { }

  ngOnInit(): void {
    this.emp_name=localStorage.getItem('log_name');
    console.log("EMP NAME : "+this.emp_name)
  }

}
