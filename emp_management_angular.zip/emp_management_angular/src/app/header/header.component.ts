import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginServService } from '../login-serv.service';
import { MessageDialogComponent } from '../message-dialog/message-dialog.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private loginService: LoginServService, private router: Router) { }

  ngOnInit(): void {



  }

  openDash() {
    console.log(localStorage.getItem("log_user_id"));
    if (localStorage.getItem("log_user_id") != null) {
      if (localStorage.getItem('log_user_id') == '123123') {
        this.router.navigate(['/dashboard']);
      }
      else
        this.router.navigate(['/dashboard']);
    }
  }

  onLogout() {
    console.log(localStorage.getItem('log_user_id'));
    localStorage.clear();
    this.router.navigate(['/login'])
  }

  isAdmin(){
    if (localStorage.getItem("log_user_id") != null) {
      if (localStorage.getItem('log_user_id') == '123123') {
        return true;
      }
      else
        return false;
    }
    else{
      return false;
    }
  }

  openHierarchy() {
    console.log(localStorage.getItem("log_user_id"));
    if (localStorage.getItem("log_user_id") != null) {
      if (localStorage.getItem('log_user_id') == '123123') {
        this.router.navigate(['/viewHierarchy']);
      }
      else
        this.router.navigate(['/userHierarchy']);
    }
  }
}
