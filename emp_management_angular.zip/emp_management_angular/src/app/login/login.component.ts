import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LoginServService } from '../login-serv.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  msg_desc;

  constructor(private fb: FormBuilder, private loginService: LoginServService, private router: Router, private _snackBar: MatSnackBar) {

  }


  ngOnInit(): void {


    this.loginForm = this.fb.group({
      emp_id: ['', Validators.compose([Validators.pattern("^[0-9]{6}$"), Validators.required])],
      password: ['', Validators.compose([Validators.pattern("^[a-zA-Z0-9.-]{6,10}$"), Validators.required])]
    });
  }

  onSubmit() {

    //if (localStorage.getItem('log_user_id') && localStorage.getItem('log_user_id') != ''){

      if (this.loginForm.valid) {
        try {
          const emp_id = this.loginForm.get('emp_id').value;
          const password = this.loginForm.get('password').value;

          //send Details to Back-end
          let userReq = {
            emp_id: emp_id,
            password: password
          }

          this.loginService.loginCheck(userReq).subscribe((res) => {

            console.log('res' + JSON.stringify(res));
            this.msg_desc = res.message.msg_desc;

            if (res && res.message && res.message.msg_code == 'Login_Success') {
              this.router.navigate(['/home'])
              localStorage.setItem('log_user_id', res.emp_id);
              localStorage.setItem('log_name',res.name);
            }
            else {
              this._snackBar.open(this.msg_desc, "!!", {
                duration: 5000,
              });
            }
          },
            (err) => {
              console.log("ERROR" + JSON.stringify(err));
            })

        } catch (err) {
          // display as backend failure

        }
      }
      else {
        //display as validation fail
      }
    /*}
    else {
      this._snackBar.open("Session Already Exists", "!!", {
        duration: 5000,
      });
    }*/
  }
}
