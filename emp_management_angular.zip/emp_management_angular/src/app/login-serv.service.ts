import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoginServService {

  private requestHeaders = new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8' });
  constructor(private http: HttpClient) {
  }

  public getMethod(): Observable<any> {
    const url = environment.apiUrl + '/';
    return this.http.get(url, {
      headers: this.requestHeaders
    });
  }

  public loginCheck(userReq): Observable<any> {
    const url = environment.apiUrl + '/loginCheck';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  public regProCheck(userReq): Observable<any> {
    const url = environment.apiUrl + '/regProCheck';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  public regPersCheck(userReq): Observable<any> {
    const url = environment.apiUrl + '/regPersCheck';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  public getRepManIdList(): Observable<any> {
    const url = environment.apiUrl + '/getRepManIdList';
    return this.http.get(url, {
      headers: this.requestHeaders
    });
  }

  public forgotPass(userReq): Observable<any> {
    const url = environment.apiUrl + '/forgotPass';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  public forgotPassUpdate(userReq): Observable<any> {
    const url = environment.apiUrl + '/forgotPassUpdate';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  public getProfileById(userReq): Observable<any> {
    const url = environment.apiUrl + '/viewProfile';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  public updateProfileById(userReq): Observable<any> {
    console.log(JSON.stringify(userReq));
    const url = environment.apiUrl + '/updateProfile';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  public addEmployee(userReq): Observable<any> {
    console.log(JSON.stringify(userReq));
    const url = environment.apiUrl + '/addEmployee';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  public delEmployee(userReq): Observable<any> {
    console.log(JSON.stringify(userReq));
    const url = environment.apiUrl + '/deleteEmployee';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  public updEmployee(userReq): Observable<any> {
    console.log(JSON.stringify(userReq));
    const url = environment.apiUrl + '/modifyEmployee';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  public dispEmployee(userReq): Observable<any> {
    console.log(JSON.stringify(userReq));
    const url = environment.apiUrl + '/displayEmployee';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }


  public viewHierarchy(userReq): Observable<any> {
    console.log(JSON.stringify(userReq));
    const url = environment.apiUrl + '/viewHierarchy';
    return this.http.post(url, userReq, {
      headers: this.requestHeaders
    });
  }

  
}
