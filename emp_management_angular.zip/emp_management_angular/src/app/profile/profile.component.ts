import { validateHorizontalPosition } from '@angular/cdk/overlay';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LoginServService } from '../login-serv.service';
import { MessageDialogComponent } from '../message-dialog/message-dialog.component';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  profileForm: FormGroup;
  public isAuth: boolean = false;
  public isEdit: boolean = false;
  public perData;
  public proData;
  hide=true;

  constructor(private fb: FormBuilder, private loginService: LoginServService, private _snackBar: MatSnackBar, private router: Router) { }

  ngOnInit(): void {

    this.onLoad();

    this.profileForm = this.fb.group({
      name: ['', Validators.compose([Validators.required, Validators.pattern('^[a-zA-Z ]{5,15}$')])],
      password: ['', Validators.compose([Validators.pattern('^[a-zA-Z0-9.-]{6,10}$'), Validators.required])],
      cpassword: ['', [Validators.required, this.crossValidation()]],
      mobile: ['', Validators.compose([Validators.pattern('^[0-9]{10}$'), Validators.required])],
      address: ['', Validators.compose([Validators.pattern('^[a-zA-Z0-9 ]{0,20}$'), Validators.required])],
    });


  }

  get cpassword(): AbstractControl {

    return this.profileForm.get('cpassword');

  }

  crossValidation(): ValidatorFn {

    return (control: AbstractControl): ValidationErrors | null => {

      let parent = control.parent;
      if (parent) {
        let password = parent.get('password').value;
        let cpassword = control.value;

        return password != cpassword ? { 'FieldValidation': 'check failed' } : null;
      }

    }

  }

  onLoad() {

    try {
      let userReq = {
        emp_id: localStorage.getItem("log_user_id")
      }

      this.loginService.getProfileById(userReq).subscribe((res) => {

        console.log(JSON.stringify(res));

        this.perData = res.pers_details[0];
        this.proData = res.prof_details[0];
        //console.log("Pers Details : " + JSON.stringify(this.perData));
        //console.log("Prof Details : " + JSON.stringify(this.proData));


        if (res && res.message.msg_code == 'Display_Success') {
          this.createAndPatchForm();

        }
      },
        (err) => {
          console.log("ERROR" + JSON.stringify(err));
        })
    }
    catch (err) {
      // display as backend failure

    }

  }

  onEdit() {
    this.isEdit = true;

  }


  createAndPatchForm() {


    console.log("Before Patch ::" + JSON.stringify(this.proData));
    this.profileForm.patchValue({
      name: this.perData.name,
      password: this.perData.password,
      cpassword: this.perData.password,
      mobile: this.perData.mobile,
      address: this.perData.address
    })
  }

  onProfileSubmit() {

    const name = this.profileForm.get('name').value;
    const password = this.profileForm.get('password').value;
    const cpassword = this.profileForm.get('cpassword').value;
    const mobile = this.profileForm.get('mobile').value;
    const address = this.profileForm.get('address').value;


    let userReq = {
      emp_id: localStorage.getItem("log_user_id"),
      name: name,
      password: password,
      mobile: mobile,
      address: address
    }

    this.loginService.updateProfileById(userReq).subscribe((res) => {
      console.log(JSON.stringify(res));
      if (res && res.message && res.message.msg_code == "Update_Success") {
        window.location.reload();
      }
      this._snackBar.open(JSON.stringify(res.message.msg_desc), "!!", {
        duration: 5000,
      });
    },
      (err) => {
        console.log("ERROR" + JSON.stringify(err));
      })
  }
}
