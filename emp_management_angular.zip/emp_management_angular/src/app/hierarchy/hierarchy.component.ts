import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LoginServService } from '../login-serv.service';

@Component({
  selector: 'app-hierarchy',
  templateUrl: './hierarchy.component.html',
  styleUrls: ['./hierarchy.component.css']
})
export class HierarchyComponent implements OnInit {

  hierForm: FormGroup;
  delivery_managers = [];
  project_managers = [];
  associates = [];
  com_emp;
  isView: boolean=false;

  constructor(private fb: FormBuilder, private loginService: LoginServService, private router: Router, private _snackBar: MatSnackBar) { }

  ngOnInit(): void {

    this.hierForm = this.fb.group({
      emp_id: ['', Validators.compose([Validators.pattern("^[0-9]{6}$"), Validators.required])],

    });
  }

  onSubmit() {

    this.isView=true;
    const emp_id = this.hierForm.get('emp_id').value;
    this.com_emp = emp_id;

    let userReq = {
      emp_id: emp_id
    }

    if (this.hierForm.valid) {

      this.loginService.viewHierarchy(userReq).subscribe((res) => {
        console.log('res' + JSON.stringify(res));
        if (res && res.length > 0) {
          this.delivery_managers = res;
        } else {
          this._snackBar.open(res.message.msg_desc, "!!", {
            duration: 2000,
          });
        }
      },
        (err) => {
          console.log("ERROR ;;" + JSON.stringify(err));
        })

    } else {
      //display as validation fail
    }
  }

  getPMs(user) {
    let userReq = {
      emp_id: user.emp_id
    }

    this.loginService.viewHierarchy(userReq).subscribe((res) => {
      console.log('res' + JSON.stringify(res));
      if (res && res.length > 0) {
        this.project_managers[user.emp_id] = res;
      }
      else {
        this._snackBar.open(res.message.msg_desc, "!!", {
          duration: 2000,
        });
      }
    },
      (err) => {
        console.log("ERROR ;;" + JSON.stringify(err));
      })
  }

  getAssociates(user) {
    let userReq = {
      emp_id: user.emp_id
    }

    this.loginService.viewHierarchy(userReq).subscribe((res) => {
      console.log('res' + JSON.stringify(res));
      if (res && res.length > 0) {
        this.associates[user.emp_id] = res;
      } else {
        this._snackBar.open(res.message.msg_desc, "!!", {
          duration: 2000,
        });
      }
    },
      (err) => {
        console.log("ERROR ;;" + JSON.stringify(err));
      })
  }
}
