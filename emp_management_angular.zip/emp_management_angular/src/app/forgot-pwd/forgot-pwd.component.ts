import { Component, OnInit } from '@angular/core';
import { AbstractControl, Form, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LoginServService } from '../login-serv.service';


@Component({
  selector: 'app-forgot-pwd',
  templateUrl: './forgot-pwd.component.html',
  styleUrls: ['./forgot-pwd.component.css']
})
export class ForgotPwdComponent implements OnInit {

  emailForm: FormGroup;
  passForm: FormGroup;
  emailHide: boolean = true;
  passHide: boolean = false;
  com_emp_id: any;
  hide = true;

  constructor(private fb: FormBuilder, private loginService: LoginServService, private router: Router, private _snackBar: MatSnackBar) {
   
  }

  ngOnInit(): void {

    this.emailForm = this.fb.group({
      emp_id: ['', Validators.compose([Validators.pattern('^[0-9]{6}$'), Validators.required])]
    });

    this.passForm = this.fb.group({
      password: ['',  Validators.compose([Validators.pattern('^[a-zA-Z0-9.-]{6,10}$'), Validators.required])],
      cpassword: ['', [Validators.required,this.confirmPassValidatorr()]]
    });

    
  }

  get cpassword(): AbstractControl{

    return this.passForm.get("cpassword")
  }

    get password(): AbstractControl{

      return this.passForm.get("password")


    }
  confirmPassValidatorr(): ValidatorFn{
    return (control: AbstractControl): ValidationErrors | null => {
        let parent=control.parent;
        if(parent)
        {
          let password=parent.get('password').value;
          let cpassword=control.value;
          return password!=cpassword? {'crossFieldValidationn':'check failed'} :null;
        }


      return null;
    };


  }

  onEmailSubmit() {
    
    if (this.emailForm.valid) {
      const emp_id = this.emailForm.get('emp_id').value;

      let userReq = {
        emp_id: emp_id
      }

      this.loginService.forgotPass(userReq).subscribe((res) => {
        console.log('res' + JSON.stringify(res));
        if (res && res.message && res.message.msg_code == "Verfication_Success") {
          this.com_emp_id = res.emp_id;
          this.emailHide = false;
          this.passHide = true;
          this._snackBar.open("Proceed..", "!!", {
            duration: 5000,
          });
         
        }
        else {
          this._snackBar.open(res.message.msg_desc, "!!", {
            duration: 5000,
          });
        }

      },
        (err) => {
          console.log("ERROR" + JSON.stringify(err));
        })
    }
  }

  onPassSubmit() {
    if (this.passForm.valid) {
      const password = this.passForm.get('password').value;
      const cpassword = this.passForm.get('cpassword').value;

      let userReq = {
        emp_id: this.com_emp_id,
        password: password
      } 
      this.loginService.forgotPassUpdate(userReq).subscribe((res) => {
        console.log('res' + JSON.stringify(res));
        if (res && res.message && res.message.msg_code == 'Password_Reset_Success') {
          this._snackBar.open("Password Reset Successfully..", "!!", {
            duration: 5000,
          });
           this.router.navigate(['/login']);
        }
        else {
          this._snackBar.open(res.message.msg_desc, "!!", {
            duration: 5000,
          });
        }
      },
        (err) => {
          console.log("ERROR" + JSON.stringify(err));
        })
    }

  }
}
