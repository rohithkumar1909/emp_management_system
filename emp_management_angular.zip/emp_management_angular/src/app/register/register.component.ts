
import { Component, OnInit } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginServService } from '../login-serv.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})


export class RegisterComponent implements OnInit {

  perForm: FormGroup;
  proForm: FormGroup;

  public isProFormHide: boolean = true;
  public isPerFormHide: boolean = false;
  public com_emp_id: any;
  hide = true;

  jobValues = ['Admin', 'Associate', 'Project Manager', 'Delivery Manager'];
  repValues = [];
  genValues = ['Male', 'Female', 'Others'];



  constructor(private fb: FormBuilder, private loginService: LoginServService, private _snackBar: MatSnackBar, private router: Router) { }

  ngOnInit(): void {

    this.onFormLoadValues();

    this.proForm = this.fb.group({
      emp_id: ['', Validators.compose([Validators.pattern("^[0-9]{6}$"), Validators.required])],
      email: ['', [Validators.compose([Validators.email, Validators.required])]],
      job_role: ['', Validators.required],
      rep_man_id: ['', Validators.compose([Validators.pattern("^[0-9]{6}$"), Validators.required])],
    });


    this.perForm = this.fb.group({

      name: ['', Validators.compose([Validators.pattern("^[a-zA-Z]{5,15}$"), Validators.required])],
      password: ['', Validators.compose([Validators.pattern("^[a-zA-Z0-9.-]{6,10}$"), Validators.required])],
      cpassword: ['', [Validators.required,this.confirmPassValidator()]],
      gender: ['', Validators.compose([Validators.required])],
      dob: ['', Validators.compose([Validators.required])],
      mobile: ['', Validators.compose([Validators.pattern("^[0-9]{10}$"), Validators.required])],
      address: ['', Validators.compose([Validators.pattern("^[a-zA-Z0-9 ]{0,20}$"), Validators.required])],
    });

  }

      get password() : AbstractControl{

        return this.perForm.get('password')
      }


      get email() : AbstractControl{

        return this.proForm.get('email')
      }

      get cpassword(): AbstractControl{

        return this.perForm.get('cpassword')
      }

  confirmPassValidator(): ValidatorFn{
    return (control: AbstractControl): ValidationErrors | null => {
        let parent=control.parent;
        if(parent)
        {
          let password=parent.get('password').value;
          let cpassword=control.value;
          return password!=cpassword? {'crossFieldValidation':'check failed'} :null;
        }


      return null;
    };


  }


  onFormLoadValues() {

    this.loginService.getRepManIdList().subscribe((res) => {
      if (res != null) {
        res.forEach(element => {
          if (element.emp_id) {
            this.repValues.push(element.emp_id)
          }
        });
      }
    },
      (err) => {
      });
  }

  onProSubmit() {

    if (this.proForm.valid) {
      const emp_id = this.proForm.get('emp_id').value;
      const email = this.proForm.get('email').value;
      const job_role = this.proForm.get('job_role').value;
      const rep_man_id = this.proForm.get('rep_man_id').value;

      let userReq = {
        emp_id: emp_id,
        email: email,
        job_role: job_role,
        rep_man_id: rep_man_id
      }

      this.loginService.regProCheck(userReq).subscribe((res) => {
        console.log(JSON.stringify(res));
        if (res && res.message && res.message.msg_code == 'Associate_Success') {
          this.isProFormHide = false;
          this.isPerFormHide = true;
          this.com_emp_id = res.emp_id;
          this._snackBar.open(res.message.msg_desc, "!!", {
            duration: 5000,
          });
        }
        else {
          this._snackBar.open(res.message.msg_desc, "!!", {
            duration: 5000,
          });
        }
      },
        (err) => {
          console.log("ERROR :: " + JSON.stringify(err));
        })
    }

  }

  onPerSubmit() {

    if (this.perForm.valid) {

      try {
        const name = this.perForm.get('name').value;
        const password = this.perForm.get('password').value;
        const gender = this.perForm.get('gender').value;
        const dob = this.perForm.get('dob').value;
        const date_value = dob.getDate() + "/" + (dob.getMonth() + 1) + "/" + dob.getFullYear();
        const mobile = this.perForm.get('mobile').value;
        const address = this.perForm.get('address').value;

        //send Details to Back-end

        let userReq = {
          emp_id: this.com_emp_id,
          name: name,
          password: password,
          gender: gender,
          dob: date_value,
          mobile: mobile,
          address: address
        }

        this.loginService.regPersCheck(userReq).subscribe((res) => {
          //Route the user to login page
          console.log(JSON.stringify(res));
          if (res && res.message && res.message.msg_code == 'Reg_Success') {
            this._snackBar.open(res.message.msg_desc, "!!", {
              duration: 5000,
            });
            this.router.navigate(['/login'])
          }
          else {
            this._snackBar.open(res.message.msg_desc, "!!", {
              duration: 5000,
            });
          }
        },
          (err) => {
            console.log("ERROR" + JSON.stringify(err));
          })
      } catch (err) {
        // display as backend failure

      }
    }
    else {
      //display as validation fail
    }
  }

}
