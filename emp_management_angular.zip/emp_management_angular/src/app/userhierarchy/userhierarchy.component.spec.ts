import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserhierarchyComponent } from './userhierarchy.component';

describe('UserhierarchyComponent', () => {
  let component: UserhierarchyComponent;
  let fixture: ComponentFixture<UserhierarchyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserhierarchyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserhierarchyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
