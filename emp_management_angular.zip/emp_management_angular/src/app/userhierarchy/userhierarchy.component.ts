import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LoginServService } from '../login-serv.service';

@Component({
  selector: 'app-userhierarchy',
  templateUrl: './userhierarchy.component.html',
  styleUrls: ['./userhierarchy.component.css']
})
export class UserhierarchyComponent implements OnInit {

  employee: any = localStorage.getItem('log_user_id');
  delivery_managers = [];
  project_managers = [];
  associates = [];
  constructor(private loginService: LoginServService, private router: Router, private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.onLoad();
  }

  onLoad() {

    let userReq = {
      emp_id: this.employee
    }

    if (this.employee != null) {
      this.loginService.viewHierarchy(userReq).subscribe((res) => {
        console.log('res' + JSON.stringify(res));
        if (res && res.length > 0) {
          this.delivery_managers = res;
        } else {
          this._snackBar.open(res.message.msg_desc, "!!", {
            duration: 2000,
          });
        }
      },
        (err) => {
          console.log("ERROR ;;" + JSON.stringify(err));
        })
    }
  }

  getPMs(user) {
    let userReq = {
      emp_id: user.emp_id
    }

    this.loginService.viewHierarchy(userReq).subscribe((res) => {
      console.log('res' + JSON.stringify(res));
      if (res && res.length > 0) {
        this.project_managers[user.emp_id] = res;
      }
      else{
        this._snackBar.open(res.message.msg_desc, "!!", {
          duration: 2000,
        });
      }
    },
      (err) => {
        console.log("ERROR ;;" + JSON.stringify(err));
      })
  }

  getAssociates(user) {
    let userReq = {
      emp_id: user.emp_id
    }

    this.loginService.viewHierarchy(userReq).subscribe((res) => {
      console.log('res' + JSON.stringify(res));
      if (res && res.length > 0) {
        this.associates[user.emp_id] = res;
      } else {
        this._snackBar.open(res.message.msg_desc, "!!", {
          duration: 2000,
        });
      }
    },
      (err) => {
        console.log("ERROR ;;" + JSON.stringify(err));
      })
  }
}
