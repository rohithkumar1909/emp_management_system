import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ForgotPwdComponent } from './forgot-pwd/forgot-pwd.component';
import { HierarchyComponent } from './hierarchy/hierarchy.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { RegisterComponent } from './register/register.component';
import { UserhierarchyComponent } from './userhierarchy/userhierarchy.component';

const routes: Routes = [{
  path: '',
  pathMatch: 'full',
  redirectTo: '/login'
},
{
  path: 'login',
  component: LoginComponent
},
{
  path: 'register',
  component: RegisterComponent
},
{
  path: 'viewProfile',
  component: ProfileComponent
},
{
  path: 'viewHierarchy',
  component: HierarchyComponent
},
{
  path: 'forgotPassword',
  component: ForgotPwdComponent
},
{
  path: 'home',
  component: HomeComponent
},
{
  path: 'dashboard',
  component: AdminDashboardComponent
},
{
  path: 'userHierarchy',
  component: UserhierarchyComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
